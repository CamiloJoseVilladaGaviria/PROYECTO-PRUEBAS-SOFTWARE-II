const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    // URL Base de tu proyecto
    baseUrl: 'https://www.bancodealimentos.org.co/',
    
    // Configuraciones de visualización y grabación
    viewportWidth: 1280,
    viewportHeight: 720,
    video: true,
    screenshotOnRunFailure: true,

    setupNodeEvents(on, config) {
      // Aquí se implementan los 'Node Event Listeners' si los necesitas.
      // Por ahora, lo dejamos vacío según la configuración estándar.
    },
  },
});