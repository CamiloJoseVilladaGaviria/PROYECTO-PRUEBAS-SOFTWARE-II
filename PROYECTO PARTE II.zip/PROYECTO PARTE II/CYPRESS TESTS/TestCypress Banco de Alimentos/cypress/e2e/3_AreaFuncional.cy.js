/// <reference types="cypress" />

describe('HU-003: Suscripción a actualizaciones de proyectos para donantes recurrentes', () => {
    
    const URL_INICIO = '/'; 
    const datosDonante = {
        nombre: 'Sofia Test',
        apellido: 'Actualizaciones',
        email: 'sofia.test.' + Date.now() + '@hotmail.com', 
        telefono: '3109876543', 
        direccion: 'Carrera 10 # 50-20',
        cumpleannos: '1990-01-01',
        observaciones: 'Test Cypress: Deseo registrarme para recibir actualizaciones.',
    };

    it('Caso de Prueba: El donante recurrente se suscribe a actualizaciones de proyectos', () => {
        
        cy.visit(URL_INICIO); 
        
        cy.get('.btnpayu a').click({ force: true });
        cy.contains('¿Cuánto te gustaría donar?', { timeout: 10000 }).should('be.visible'); 

        cy.contains('$50.000').click(); 
        
        cy.get('input[name="donor[first_name]"]').type(datosDonante.nombre);      
        cy.get('input[name="donor[last_name]"]').type(datosDonante.apellido);    
        cy.get('input[name="donor[email]"]').type(datosDonante.email);          
        cy.get('input[name="donor[phone]"]').type(datosDonante.telefono);        
        cy.get('input[name="donor[cumpleannos]"]').type(datosDonante.cumpleannos); 
        cy.get('textarea[name="donor[address]"]').type(datosDonante.direccion);      
        cy.get('textarea[name="donor[notes]"]').type(datosDonante.observaciones);    
        
        cy.get('input[name="donor[tyc]"]').check({ force: true }).should('be.checked');
        
        cy.get('button.btn-submit').contains('Donar').click(); 

        cy.url().should('include', 'checkout.payulatam.com'); 
        cy.contains('Total a pagar').next().should('have.text', '$50.000.00');
    });
});
