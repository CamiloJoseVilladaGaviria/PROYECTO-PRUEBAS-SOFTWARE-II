/// <reference types="cypress" />

Cypress.on('uncaught:exception', (err, runnable) => {
    return false; // Ignora errores JS externos al test
});

describe('HU-006: Visualización de Noticias y Actualizaciones', () => {
    
    const ENLACE_MENU = 'Blog';
    const ORIGEN_BLOG = 'https://blog.bancodealimentos.org.co';
    const SELECTOR_CONTENEDOR_POST = '.type-post, .post-item, article';
    const SELECTOR_TITULO = 'h2, .entry-title, .post-title';
    const SELECTOR_FECHA = '.entry-meta, .post-date';

    it('Caso de Prueba #6: Verificar visualización de noticias y publicaciones recientes', () => {
        
        cy.visit('https://www.bancodealimentos.org.co/');
        cy.contains('a', ENLACE_MENU, { matchCase: false }).click();

        cy.origin(ORIGEN_BLOG, { args: { SELECTOR_CONTENEDOR_POST, SELECTOR_TITULO, SELECTOR_FECHA } }, ({ SELECTOR_CONTENEDOR_POST, SELECTOR_TITULO, SELECTOR_FECHA }) => {
            
            cy.url().should('include', 'blog');

            cy.get(SELECTOR_CONTENEDOR_POST, { timeout: 10000 })
              .should('have.length.of.at.least', 1)
              .first()
              .within(() => {
                  cy.get(SELECTOR_TITULO).should('be.visible').and('not.be.empty');
                  cy.get(SELECTOR_FECHA).should('be.visible').and('not.be.empty');
              });
        });
    });
});
