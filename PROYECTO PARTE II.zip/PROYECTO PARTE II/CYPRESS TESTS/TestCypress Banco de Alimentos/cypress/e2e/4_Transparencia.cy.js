/// <reference types="cypress" />

describe('HU-004: Verificación de Informe de Gestión', () => {
    
    const URL_BASE = 'https://www.bancodealimentos.org.co/';

    it('Caso de Prueba #4: El visitante verifica la visualización del Informe de Gestión', () => {
        
        cy.visit(URL_BASE);

        cy.contains('a', 'Nosotros').trigger('mouseover');

        cy.contains('a', 'Informes de Gestión', { matchCase: false })
          .click({ force: true });

        cy.url().should('include', '/informes-de-gestion/');

        cy.contains('Informe de Gestión 2024') 
          .parents('.vc_column-inner') 
          .within(() => {
              cy.contains('button', 'Leer')
                  .parent('a')
                  .as('enlacePDF');
          });

        cy.get('@enlacePDF')
          .should('be.visible')
          .invoke('removeAttr', 'target')
          .click();

        cy.url().should('include', '.pdf');

        cy.go('back');
        cy.url().should('include', '/informes-de-gestion/');
    });
});
