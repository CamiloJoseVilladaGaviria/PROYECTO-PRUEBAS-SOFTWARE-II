describe('HU-009: Verificación de Multimedia en Banco de Alimentos', () => {
    
    const URL_DEL_BANCO = 'https://www.bancodealimentos.org.co/';

    beforeEach(() => {
        cy.visit(URL_DEL_BANCO);
        cy.url().should('eq', URL_DEL_BANCO);
        cy.log('Navegación completada a la página principal.');
    });

    it('Debe verificar la existencia y visibilidad de las imágenes y el video destacado', () => {
        
        // Verificación de Imágenes
        cy.get('img:visible', { timeout: 15000 }).should('exist') 
            .each(($img) => {
                const imgUrl = $img.attr('src');
                cy.wrap($img).should('be.visible').and('have.attr', 'src'); 
                
                cy.window().then(() => {
                    const img = $img[0];
                    if (img.complete && img.naturalWidth === 0) {
                        cy.log(`⚠️ Imagen no cargada o rota: ${imgUrl}`);
                    } else {
                        cy.log(`✅ Imagen cargada correctamente: ${imgUrl ? imgUrl.substring(0, 50) + '...' : 'URL no disponible'}`);
                    }
                });
            });
            
        // Verificación del Video Destacado 
        const videoSectionSelector = 'div.wpb_wrapper'; 
        cy.get(videoSectionSelector, { timeout: 25000 }) 
            .should('exist');

        cy.get(videoSectionSelector)
            .find('video:visible, iframe:visible')
            .first()
            .should('exist')
            .and('be.visible');

        cy.log('✅ Prueba completada: El componente de video está presente y visible en el DOM.');
    });
});
