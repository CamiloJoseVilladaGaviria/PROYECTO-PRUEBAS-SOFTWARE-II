// Historia de Usuario 14 (HU-14): Verificacion de Sección de Impacto 

describe('HU-014: Verificación de Sección de Impacto (Texto y Video)', () => {
    
    const URL_DEL_BANCO = 'https://www.bancodealimentos.org.co/';

    beforeEach(() => {
        cy.visit(URL_DEL_BANCO);
    });

    it('Debe verificar la existencia del título, el texto descriptivo y el video del impacto', () => {
        
        // Verificación del Título de la Sección
        const TITLE_TEXT = '¿Qué hace el Banco de Alimentos?';

        cy.contains('h1, h2, h3, h4', TITLE_TEXT, { timeout: 20000 }) 
            .should('exist')
            .and('be.visible')
            .as('SectionTitle');

        // Verificación del Texto Descriptivo
        cy.get('div.wpb_text_column.wpb_content_element', { timeout: 10000 })
            .should('exist')
            .and('be.visible')
            .find('p')
            .first()
            .invoke('text')
            .should('have.length.at.least', 50);

        // Verificación del Video Asociado
        const VIDEO_ELEMENT_SELECTOR = 'video:visible, iframe:visible';
        cy.get(VIDEO_ELEMENT_SELECTOR, { timeout: 20000 }) 
            .should('exist')
            .and('be.visible');

        cy.log('**PRUEBA HU-014 FINALIZADA EXITOSAMENTE**');
    });
});
