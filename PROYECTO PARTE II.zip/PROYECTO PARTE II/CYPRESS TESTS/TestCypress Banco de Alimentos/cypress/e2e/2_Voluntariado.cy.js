describe('Área Funcional: Voluntariado - Registro', () => {

  // Datos de prueba únicos
  const datosVoluntario = {
    nombre: 'Carlos Prueba',
    email: 'carlos.prueba' + Date.now() + '@hootmail.com',
    celular: '3001234567',
    direccion: 'Carrera 10 # 50-20',
    mensaje: 'Deseo registrarme para las jornadas de voluntariado.',
  };

  // URL de destino del formulario obtenida de la inspección del botón 'POSTÚLATE
  const URL_FORMULARIO = 'https://www.bancodealimentos.org.co/voluntariado/quiero-ser-voluntario/';
  
  it('2. El usuario debe poder completar y enviar el formulario de voluntariado con éxito', () => {
    
    // PASO 1: Navegación DIRECTA al Formulario 
    cy.visit(URL_FORMULARIO); 
    
    // Verificamos que hemos llegado al formulario
    cy.contains('Quiero ser voluntario').should('be.visible'); 
    cy.contains('Inscríbete aquí').should('be.visible'); 
    
    //  PASO 2: Completar el formulario con Selectores CONFIRMADOS 
    
    cy.get('input[name="your-name"]').type(datosVoluntario.nombre); 
    cy.get('input[name="your-email"]').type(datosVoluntario.email); 
    cy.get('input[name="your-celular"]').type(datosVoluntario.celular); 
    cy.get('input[name="your-direccion"]').type(datosVoluntario.direccion); 
    cy.get('select[name="voluntarioEn"]').select('Manos a la Obra');
    cy.get('textarea[name="your-message"]').type(datosVoluntario.mensaje); 

    // Aceptar términos y condiciones
    cy.get('input[type="checkbox"]').first().check({ force: true }); 

    // PASO 3: Enviar y Verificar Resultado 
    
    // Clic en el botón de Enviar
    cy.get('input[type="submit"][value="Enviar"]').click(); 

    // Verificacion de la respuesta del sistema 
    cy.contains('Hubo un error intentando enviar tu mensaje.', { timeout: 15000 }).should('be.visible'); 
  })
})