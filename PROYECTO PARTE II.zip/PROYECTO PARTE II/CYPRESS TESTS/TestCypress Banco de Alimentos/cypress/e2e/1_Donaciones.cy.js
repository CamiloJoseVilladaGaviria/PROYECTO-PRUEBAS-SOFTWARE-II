/// <reference types="cypress" />

describe('HU-XXX: Acceso a información de donaciones', () => {

  it('Caso de Prueba: El visitante accede fácilmente a la información sobre cómo donar', () => {
    
    // 1. Visitar el sitio web
    cy.visit('/'); 
    
    // Verificación de carga de la página principal
    cy.contains('Banco de Alimentos de Bogotá', { matchCase: false }).should('be.visible'); 

    // 2. Clic en Donaciones (Selector estable)
    cy.get('.btn-donate')
      .should('be.visible')
      .first()
      .click(); 

    // 3. Verificaciones en la página de destino
    cy.url().should('include', '/donaciones-recurrentes/'); 

    cy.get('h1').contains('Donaciones Recurrentes').should('be.visible'); 
  });
});
