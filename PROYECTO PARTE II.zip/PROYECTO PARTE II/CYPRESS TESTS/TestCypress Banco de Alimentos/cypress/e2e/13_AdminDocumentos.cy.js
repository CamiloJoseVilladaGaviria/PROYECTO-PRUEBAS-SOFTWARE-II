describe('HU-013: Acceso Privado a Documentos Internos', () => {

  const LOGIN_URL = '/login';               // URL del formulario de acceso interno
  const DOCUMENTOS_URL = '/documentos-internos';  // Sección protegida
  const USUARIO_VALIDO = 'empleado_demo';
  const PASSWORD_VALIDO = 'clave_segura';

  before(() => {
    cy.log('Simulación de acceso al área privada');
  });

  it('Debe impedir el acceso sin autenticación', () => {
    // Paso 1: Intentar ingresar directamente sin sesión
    cy.visit(DOCUMENTOS_URL, { failOnStatusCode: false });

    // Aserción 1: Verificar redirección o mensaje de acceso denegado
    cy.url().should('include', '/login').or(() => {
      cy.contains('Acceso restringido').should('be.visible');
    });
  });

  it('Debe permitir acceso al usuario autenticado', () => {
    // Paso 2: Acceder al formulario de inicio de sesión
    cy.visit(LOGIN_URL);
    cy.get('input[name="username"]').type(USUARIO_VALIDO);
    cy.get('input[name="password"]').type(PASSWORD_VALIDO);
    cy.get('button[type="submit"]').click();

    // Paso 3: Validar acceso al área interna
    cy.url({ timeout: 10000 }).should('include', DOCUMENTOS_URL);
    cy.contains('Documentos Internos').should('be.visible');

    cy.log('✅ Acceso privado verificado correctamente.');
  });
});
