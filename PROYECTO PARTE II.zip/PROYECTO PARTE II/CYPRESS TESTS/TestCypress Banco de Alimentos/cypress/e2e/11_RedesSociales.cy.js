/// <reference types="cypress" />

describe('HU 11 - Acceso a redes sociales oficiales', () => {

  beforeEach(() => {
    cy.visit('https://www.bancodealimentos.org.co/');
  });

  it('Verifica que los íconos de redes sociales sean visibles y funcionales', () => {
    // Validar que el footer o encabezado esté visible
    cy.get('footer', { timeout: 10000 }).should('be.visible');

    // Verificar enlaces de redes sociales
    const redes = [
      { nombre: 'Facebook', selector: 'a[href*="facebook.com"]' },
      { nombre: 'Instagram', selector: 'a[href*="instagram.com"]' },
      { nombre: 'YouTube', selector: 'a[href*="youtube.com"]' },
      { nombre: 'LinkedIn', selector: 'a[href*="linkedin.com"]' }
    ];

    redes.forEach(red => {
      cy.get(red.selector)
        .should('have.attr', 'href')
        .and('include', red.nombre.toLowerCase());

      cy.get(red.selector)
        .should('be.visible')
        .then($link => {
          const url = $link.prop('href');
          cy.log(`🌐 Verificando enlace de ${red.nombre}: ${url}`);
          expect(url).to.contain(red.nombre.toLowerCase());
        });
    });
  });
});
