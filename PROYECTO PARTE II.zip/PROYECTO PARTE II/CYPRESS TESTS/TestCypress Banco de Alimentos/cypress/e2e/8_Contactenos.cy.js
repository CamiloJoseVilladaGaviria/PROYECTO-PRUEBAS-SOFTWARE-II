/// <reference types="cypress" />

describe('Área Funcional: Contáctenos (HU #8) - Envío Verificado (TEST FINAL)', () => {
    
    // 🔹 Selectores esenciales
    const ENLACE_CONTACTO = 'Contáctenos'; 
    const SELECTOR_CAMPO_NOMBRE = 'input[name="your-name"]';
    const SELECTOR_CAMPO_CORREO = 'input[name="your-correo"]';
    const SELECTOR_CAMPO_TELEFONO = 'input[name="your-phone"]';
    const SELECTOR_CAMPO_MENSAJE = 'textarea[name="your-message"]';
    const SELECTOR_CHECKBOX_ACEPTACION = 'input[name="acceptance-182"]';
    const SELECTOR_BOTON_ENVIAR = 'input.wpcf7-form-control.wpcf7-submit.cms-button';
    const SELECTOR_MENSAJE_RESPUESTA = '.wpcf7-response-output'; 
    const SELECTOR_PRIMER_CONTENEDOR_FORMULARIO = '.vc_column_container:has(input[name="your-name"])'; 

    const DATOS_PRUEBA = {
        nombre: 'Cypress Donante Prueba',
        correo: 'cypress.donante@pruebacypress.com',
        telefono: '3001234567',
        mensaje: 'Prueba 8 Solicitud de información de donación. NO RESPONDER.'
    };

    it('Caso de Prueba #8: El usuario llena y envía el formulario, verificando la respuesta del sistema (TEST ESTABLE)', () => {
        // 1️⃣ Navegación
        cy.visit('https://www.bancodealimentos.org.co/');
        cy.contains('a', ENLACE_CONTACTO, { matchCase: false }).click({ force: true }); 
        // 2️⃣ Espera de carga
        cy.get(SELECTOR_PRIMER_CONTENEDOR_FORMULARIO, { timeout: 15000 }).should('be.visible'); 
        cy.log('✅ Formulario cargado.');
        // 3️⃣ Llenar el formulario
        cy.get(SELECTOR_CAMPO_NOMBRE).type(DATOS_PRUEBA.nombre, { force: true });
        cy.get(SELECTOR_CAMPO_CORREO).type(DATOS_PRUEBA.correo, { force: true }); 
        cy.get(SELECTOR_CAMPO_TELEFONO).type(DATOS_PRUEBA.telefono, { force: true });
        cy.get(SELECTOR_CAMPO_MENSAJE).type(DATOS_PRUEBA.mensaje, { force: true });
        cy.log('✅ Campos diligenciados.');
        // 4️⃣ Aceptar política de datos
        cy.get(SELECTOR_CHECKBOX_ACEPTACION).click({ force: true });
        cy.log('✅ Checkbox marcado.');
        // 5️⃣ Enviar formulario
        cy.get(SELECTOR_BOTON_ENVIAR)
          .should('exist')
          .click({ force: true });
        cy.log('✅ Botón de envío clickeado.');
        // 6️⃣ Validar mensaje de respuesta
        cy.get(SELECTOR_MENSAJE_RESPUESTA, { timeout: 20000 })
          .should('be.visible')
          .and('not.be.empty'); 
        cy.log('🎉 Validación de envío completada y respuesta verificada. Test en verde.');
    });
});
