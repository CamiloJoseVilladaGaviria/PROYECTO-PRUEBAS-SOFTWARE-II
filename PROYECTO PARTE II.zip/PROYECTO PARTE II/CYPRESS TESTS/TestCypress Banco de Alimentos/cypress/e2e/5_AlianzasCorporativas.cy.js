/// <reference types="cypress" />

describe('HU-005: Verificación de Alianzas Corporativas', () => {
    
    const URL_BASE = 'https://www.bancodealimentos.org.co/';
    const ENLACE_SUBMENU = 'RSE';
    const URL_ESPERADA = '/responsabilidad-social-empresarial/';

    it('Caso de Prueba #5: Verificar disponibilidad de información de Alianzas Corporativas', () => {
        
        cy.visit(URL_BASE);

        cy.contains('a', 'Ayúdanos a ayudar')
          .should('be.visible')
          .trigger('mouseover');

        cy.contains('a', ENLACE_SUBMENU)
          .click({ force: true });

        cy.url().should('include', URL_ESPERADA);

        cy.contains('h1', 'Responsabilidad Social Empresarial', { matchCase: false, timeout: 5000 })
          .should('be.visible');
    });
});
