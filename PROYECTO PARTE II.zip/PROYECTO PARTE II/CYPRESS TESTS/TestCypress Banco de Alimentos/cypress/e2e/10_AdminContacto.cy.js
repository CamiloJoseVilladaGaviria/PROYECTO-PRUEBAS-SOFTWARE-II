describe('HU-005: Actualización de datos de contacto', () => {
  before(() => {
    // Iniciar sesión como administrador antes de todo
    cy.loginAdmin();
  });
  it('Debe actualizar y luego revertir los datos de contacto correctamente', () => {
    cy.log('🧭 Accediendo a la página de opciones de contacto...');
    // 🔹 Ajusta esta URL según tu panel o plugin
    cy.visit('/wp-admin/admin.php?page=contact-options');
    // Guardar los valores actuales (para revertir luego)
    cy.get('#contact_phone').invoke('val').as('telefonoOriginal');
    cy.get('#contact_email').invoke('val').as('correoOriginal');
    cy.get('#contact_address').invoke('val').as('direccionOriginal');
    // Nuevos valores temporales
    const nuevoTelefono = '601 9999999';
    const nuevoCorreo = 'info@ejemplo.org';
    const nuevaDireccion = 'Calle Falsa 123, Bogotá';
    cy.log('Actualizando datos de contacto...');
    cy.get('#contact_phone').clear().type(nuevoTelefono);
    cy.get('#contact_email').clear().type(nuevoCorreo);
    cy.get('#contact_address').clear().type(nuevaDireccion);
    cy.get('input[type="submit"]').click();
    // Validar mensaje de éxito
    cy.contains('Configuración guardada').should('be.visible');
    cy.log('🔍 Verificando cambios en el sitio público...');
    cy.visit('/');
    cy.contains(nuevoTelefono).should('exist');
    cy.contains(nuevoCorreo).should('exist');
    cy.contains('Calle Falsa 123').should('exist');
    // Revertir cambios
    cy.log('↩️ Revirtiendo cambios a los valores originales...');
    cy.loginAdmin();
    cy.visit('/wp-admin/admin.php?page=contact-options');
    cy.get('@telefonoOriginal').then(tel => {
      cy.get('#contact_phone').clear().type(tel);
    });
    cy.get('@correoOriginal').then(mail => {
      cy.get('#contact_email').clear().type(mail);
    });
    cy.get('@direccionOriginal').then(dir => {
      cy.get('#contact_address').clear().type(dir);
    });
    cy.get('input[type="submit"]').click();
    cy.contains('Configuración guardada').should('be.visible');
  });
});
