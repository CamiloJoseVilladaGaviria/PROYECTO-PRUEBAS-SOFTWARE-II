/// <reference types="cypress" />

describe('HU-007: Consulta de Proyectos y Programas', () => {
    
    const ENLACE_MENU_PRINCIPAL = 'Ayúdanos a ayudar';
    const SELECTOR_TITULO_PAGINA = 'h1, h2';
    const SELECTOR_CONTENEDOR_CONTENIDO = '.vc_row, .vc_column';

    //CASO 1: PROGRAMA NUTRICIÓN INTEGRAL 
    it('Caso A: Verificar consulta de PROGRAMA NUTRICIÓN INTEGRAL', () => {
        const PROGRAMA = 'PROGRAMA NUTRICIÓN INTEGRAL';
        
        cy.visit('https://www.bancodealimentos.org.co/');
        cy.contains('a', ENLACE_MENU_PRINCIPAL, { matchCase: false }).trigger('mouseover').wait(500);
        cy.contains('a', PROGRAMA, { matchCase: false }).click({ force: true });

        cy.url().should('include', 'nutricion-integral');
        cy.get(SELECTOR_TITULO_PAGINA).should('be.visible').and('not.be.empty');
        cy.get(SELECTOR_CONTENEDOR_CONTENIDO, { timeout: 10000 }).should('have.length.of.at.least', 5);
    });

    // CASO 2: PROGRAMA CORABASTOS 
    it('Caso B: Verificar consulta de PROGRAMA CORABASTOS', () => {
        const PROGRAMA = 'PROGRAMA CORABASTOS';
        
        cy.visit('https://www.bancodealimentos.org.co/');
        cy.contains('a', ENLACE_MENU_PRINCIPAL, { matchCase: false }).trigger('mouseover').wait(500);
        cy.contains('a', PROGRAMA, { matchCase: false }).click({ force: true });

        cy.url().should('include', 'corabastos');
        cy.get(SELECTOR_TITULO_PAGINA).should('be.visible').and('not.be.empty');
        cy.get(SELECTOR_CONTENEDOR_CONTENIDO, { timeout: 10000 }).should('have.length.of.at.least', 5);
    });

    // CASO 3: PROGRAMA PREA 
    it('Caso C: Verificar consulta del programa PREA', () => {
        const PROGRAMA = 'PREA';
        
        cy.visit('https://www.bancodealimentos.org.co/');
        cy.contains('a', ENLACE_MENU_PRINCIPAL, { matchCase: false }).trigger('mouseover').wait(500);
        cy.contains('a', PROGRAMA, { matchCase: false }).click({ force: true });

        cy.url().should('include', 'prea');
        cy.get(SELECTOR_TITULO_PAGINA).should('be.visible').and('not.be.empty');
        cy.get(SELECTOR_CONTENEDOR_CONTENIDO, { timeout: 10000 }).should('have.length.of.at.least', 5);
    });
});
