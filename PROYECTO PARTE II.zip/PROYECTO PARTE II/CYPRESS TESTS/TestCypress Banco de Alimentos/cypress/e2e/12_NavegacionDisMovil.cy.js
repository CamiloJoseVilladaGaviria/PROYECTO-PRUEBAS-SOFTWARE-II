<reference types="cypress" />
describe('HU-012: Navegación móvil del sitio', () => {
  const URL_SITIO = 'https://www.bancodealimentos.org.co/';
  beforeEach(() => {
    // Simula la vista móvil 
    cy.viewport('iphone-x');
    cy.visit(URL_SITIO);
  });
  it('Debe cargar correctamente la página principal en vista móvil', () => {
    // Esperar que cargue el contenido principal
    cy.get('header', { timeout: 10000 }).should('be.visible');
    cy.get('main', { timeout: 10000 }).should('be.visible');
    cy.get('footer', { timeout: 10000 }).should('be.visible');

    cy.log('✅ Página cargada correctamente en vista móvil.');
  });
  it('Debe mostrar el menú móvil y permitir la navegación', () => {
    // Buscar el botón de menú (puede variar según la plantilla)
    cy.get('button, .menu-toggle, .hamburger', { timeout: 10000 })
      .first()
      .should('be.visible')
      .click();
    // Verificar que el menú se desplegó
    cy.get('nav, .mobile-menu, .menu', { timeout: 10000 })
      .should('be.visible');

    cy.log('✅ Menú móvil desplegado correctamente.');
    // Validar que los enlaces del menú existan
    cy.get('nav a')
      .should('have.length.greaterThan', 0)
      .first()
      .click();

    cy.log('✅ Enlaces del menú móvil son funcionales.');
  });

  it('Debe mostrar correctamente el pie de página en vista móvil', () => {
    cy.scrollTo('bottom');
    cy.get('footer').should('be.visible');
    cy.get('footer a')
      .should('have.length.greaterThan', 0)
      .and('be.visible');

    cy.log('✅ Footer visible y accesible desde móvil.');
  });
});
