// cypress/support/commands.js

Cypress.Commands.add('loginAdmin', () => {
  const username = Cypress.env('admin_user') || 'user_admin';
  const password = Cypress.env('admin_pass') || 'password_seguro';

  cy.log('🔐 Iniciando sesión de administrador en WordPress...');

  // Limpiar cookies y almacenamiento
  cy.clearCookies();
  cy.clearLocalStorage();

  // Visitar la página de login
  cy.visit('/wp-login.php');

  // Llenar el formulario de login
  cy.get('#user_login', { timeout: 10000 }).should('be.visible').clear().type(username);
  cy.get('#user_pass', { timeout: 10000 }).should('be.visible').clear().type(password);
  cy.get('#wp-submit', { timeout: 10000 }).should('be.visible').click();

  // Verificar redirección al panel
  cy.url({ timeout: 10000 }).should('include', '/wp-admin');

  // Verificar que la barra de administrador sea visible
  cy.get('#wpadminbar', { timeout: 10000 }).should('be.visible');

  cy.log('🎉 Sesión de administrador establecida correctamente.');
});
